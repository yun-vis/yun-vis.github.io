extern double	getETime	( void );
extern void	checkInETime	( void );
extern double	checkOutETime	( void );
extern double	getCPUTime	( void );
extern void	checkInCPUTime	( void );
extern double	checkOutCPUTime	( void );
extern void	reportTime	( void );

