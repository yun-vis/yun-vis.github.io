Please drag 3D model files (*.off) to the executable file
icon (unfold.exe) for the demonstration. Or you can use
powershell and type

% unfold *.off

in the directory that contains the exectutable and data
files.
